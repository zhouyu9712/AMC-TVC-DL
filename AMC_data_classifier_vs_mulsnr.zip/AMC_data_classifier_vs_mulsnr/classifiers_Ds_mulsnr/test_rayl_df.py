# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model,load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from hard_judge import *
from readdata import *
# -----------------------------------------
# parameter setting
# -----------------------------------------
N_SYMS1   = 36000                  #  Data length of one frame
DS_VEC    = [10,150]               #  Doppler shift parameter vector; 10 or 150
To        = 76.8                   #  the number of train frame
# -----------------------------------------
# training process for 4 cycle
# 1. different doppler shift
# 2. different resolution
# 3. different classifiers
# 4. different snrs
# -----------------------------------------
for dd in range(0,len(DS_VEC),1):  #  cycle for doppler shift

    if DS_VEC[dd]==10:
        RR = [64,32,16]             # R resolution ; complexity
    else:
        RR = [64]

    for rr in range(0,len(RR),1):   # cycle for R
        N_L_in = RR[rr]             #  R resolution ; complexity
        SNRK = 24                   #  Number of SNR types 0:23
        net = [1,2]                 #  net=1:MCBLDN; net=2:SCDN

        for jj in range(0, len(net), 1):  # cycle for net / MCBLDN/CSDN
            if net[jj] == 1:  #
                if DS_VEC[dd]==10:
                    num_tim = 4000        # the data length of each slots vector for slow fading channel
                else:
                    num_tim = 1200        # the data length of each slots vector for fast fading channel
            else:
                num_tim = N_SYMS1   # num_tim=N_SYMS1 no slotted-CD
            N_Time = math.floor(N_SYMS1 / num_tim)

            # -----------------------------------------
            # File path of saved model
            # -----------------------------------------
            if net[jj] == 1:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_SNR\MCCBLDN\DS_" + str(
                    DS_VEC[dd]) + "\stmp_Ds" + str(DS_VEC[dd]) + "_crnn_R" + str(2 * N_L_in) + "_L" + str(
                    N_Time) + "_N"+ str(int(num_tim)) + "To" + str(To) + ".h5"

            else:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_SNR\SCDN\DS_" + str(
                    DS_VEC[dd]) + "\stmp_Ds" + str(DS_VEC[dd]) + "_scnn_R" + str(2 * N_L_in) + "_L" + str(
                    N_Time) + "_N" + str(int(num_tim)) + "To" + str(To) + ".h5"

            checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)

            # -----------------------------------------
            # load model
            # -----------------------------------------
            model = load_model(save_path)
            model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()
            # -----------------------------------------
            # Initialize variables for storage
            # -----------------------------------------
            snr = np.linspace(0, SNRK-1 , SNRK, endpoint=True, dtype='int8')  # snr vector
            accuracy = np.zeros([1, len(snr)]) # save accuracy for each snr
            matrix = np.zeros([len(snr), 8, 8]) # save detail modulation formats accuracy for each snr
            # ------------------------------------
            # load new data for test; File path of the data set
            # ------------------------------------
            path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleighsnr\stest_paper\Cons'
            for i in range(len(snr)):
                dataFiletest = path + '\Con_' + str(2 * N_L_in) + '_Ds' + str(DS_VEC[dd]) + '_' + str(
                    num_tim) + '_' + str(N_Time) + '_3T_mod_CNN_1kind_sin_' + str(snr[i]) + '_dB120ruli_1.01sig_uint8.mat'
                # load test data and evaluate
                if net[jj] == 1 :
                    [list1, output_train] = whether_slots_numpy_to_list(n_to_l=1, dataFile=dataFiletest, IQ=0,N_Time=N_Time)
                    print('\nTesting ------------')
                    loss, accuracy[0, i] = model.evaluate(list1, output_train) # Test model to obtain classification accuracy
                    matrix[i, :, :] = Modu_ways_statistics(list1, model, output_train)  # obtain deatail classification accuracy for each mod format
                else:
                    [input_train, output_train] = whether_slots_numpy_to_list(n_to_l=0, dataFile=dataFiletest, IQ=0, N_Time=N_Time)
                    print('\nTesting ------------')
                    loss, accuracy[0, i] = model.evaluate(input_train, output_train)
                    matrix[i, :, :] = Modu_ways_statistics(input_train, model, output_train)

                print('Identification matrix:\n', matrix[i, :, :])
                print('test loss: ', loss)
                print('the snr is ', snr[i])
                print('test accuracy: ', accuracy[0, i])
            print('test accuracy: ', accuracy)

            # scio.savemat(dataNew, {'acc1':accuracy, }) save accuracy and matrix
            dataNew = 'F:\matlab\plot_data\Paper\DS_' + str(DS_VEC[dd]) + '\s' + str(2 * N_L_in) + 'net' + str(
                net[jj]) + 'format_Ds' + str(DS_VEC[dd]) + 'snr0-23.mat'
            scio.savemat(dataNew, {'acc': accuracy, 'matrix': matrix})








