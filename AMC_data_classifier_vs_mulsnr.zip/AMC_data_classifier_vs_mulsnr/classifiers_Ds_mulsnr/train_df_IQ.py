# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model, load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from readdata import *
# -----------------------------------------
# parameter setting
# -----------------------------------------
DS_VEC = [10,150]   #  Doppler shift parameter vector; 0:AWGN
N_SYMS1   = 36000   #  Data length of one frame
net=3               #  net=1:MCBLDN; net=2:SCDN 3: ResNet
SNRK=24             #  Number of SNR types 0:23
tra_totaln = 76.8   #  the number of frame
N_L_in = 64         #  only for load test data
num_tim = N_SYMS1   #  there is no slotted
N_Time = math.floor(N_SYMS1 / num_tim)  # L in paper
# -----------------------------------------
# training process for 1 cycle
# 1. different doppler shift
# -----------------------------------------
for z in range(0,len(DS_VEC),1): # cycle for doppler shift
    j=DS_VEC[z]
    if j==150:
        epch=150
    else:
        epch=200

    First_train = True                      # Is it the first training
    train = 1
    # -----------------------------------------------------------------
    # when you are using train=0,please make frist_train=false
    # -----------------------------------------------------------------
    if train == 0 :
        First_train = False
    # -----------------------------------------
    # path of saved model
    # -----------------------------------------

    save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\RESPONSE\Eightmod_vs_IQ\IQ_RN\DS_"+str(j)+"\stmp_Ds" + str(
        j) + "snr0_" + str(SNRK-1) + "_scnn_L" + str(N_Time) + "_N" + str(int(num_tim / 100)) + "_"+str(tra_totaln)+".h5"

    checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)

    # -----------------------------------------
    # creat model/ load saved model
    # -----------------------------------------
    if First_train == True:

        model = resnet_IQ_for36(N_SYMS1, 8) # ResNet for 36000

    else:
        model = load_model(save_path)
    model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    model.summary()

    if train == 1:
        # ----------------------------------------
        # File path of the data set
        # -----------------------------------------
        path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleighsnr\strain\IQ_two'

        dataFile = path + '\IQ_'+ str(2 * N_L_in) +'_Ds' + str(j) + '_' + str(num_tim) + '_' + str(N_Time) + '_' + str(
            tra_totaln) + 'T_mod_CNN_' + str(SNRK) + 'kind_MUL_dB120_ruili_1.01sig_0.mat'
        [input_train, output_train] = mat_h5py_load(dataFile, IQ=1)
        # ------------------------------------------
        # load train data
        # ------------------------------------------
        print('Training ------------')
        model.fit(input_train, output_train, epochs=epch, batch_size=120, validation_split=0.05, verbose=2,
                  shuffle=True, callbacks=[checkpoint])
        # model.fit_generator(generator(),epochs=epch, batch_size=300, validation_split=0.15, verbose=2,shuffle=True, callbacks=[checkpoint])
    else:
        print('there is not train ')









