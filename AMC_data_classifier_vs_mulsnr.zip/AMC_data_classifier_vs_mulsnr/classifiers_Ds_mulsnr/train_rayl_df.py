# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model,load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from readdata import *
First_train = True # Is it the first training
train=1
#-----------------------------------------------------------------
# when you are using train=0, please make frist_train=false
#-----------------------------------------------------------------
if train==0:
    First_train = False
# -----------------------------------------
# parameter setting
# -----------------------------------------
N_SYMS1  =  36000               #  Data length of one frame
DS_VEC   =  [10,150]            #  Doppler shift parameter vector; 10 or 150
SNRK=24                         #  Number of SNR types 0:23
tra_totaln=76.8                 #  the number of frame
net=[1,2]                       #  net=1:MCBLDN; net=2:SCDN
# -----------------------------------------
# training process for 3 cycle
# 1. different doppler shift
# 2. different resolution
# 3. different classifiers
# -----------------------------------------
for dd in range(0,len(DS_VEC),1):  # cycle for doppler shift
    if DS_VEC[dd]==10:
        RR = [16,32,16]            # R resolution ; complexity
    else:
        RR = [64]

    for rr in range(0, len(RR), 1): #  cycle for resolution
        N_L_in = RR[rr]             #  R resolution ; complexity
        for jj in range(0, len(net), 1):  # cycle for classifiers

            if net[jj] == 1:  #
                if DS_VEC[dd] == 10:
                    num_tim = 4000  # the data length of each slots vector for slow fading channels
                else:
                    num_tim = 1200  # the data length of each slots vector for fast fading channels
            else:
                num_tim = N_SYMS1   # num_tim=N_SYMS1 no slotted-CD

            N_Time = math.floor(N_SYMS1 / num_tim)  # L in paper
            # -----------------------------------------
            # path of saved model
            # -----------------------------------------
            if net[jj] == 1:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_SNR\MCCBLDN\DS_" + str(
                    DS_VEC[dd]) + "\stmp_Ds" + str(
                    DS_VEC[dd]) + "_crnn_R" + str(2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(int(num_tim))+"To" +str(tra_totaln)+ ".h5"
            else:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_SNR\SCDN\DS_" + str(
                    DS_VEC[dd]) + "\stmp_Ds" + str(DS_VEC[dd]) + "_scnn_R" + str(2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(
                    int(num_tim)) + "To" + str(tra_totaln) + ".h5"

            checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)
            # -----------------------------------------
            # creat model/ load saved model
            # -----------------------------------------
            if First_train == True:
                if net[jj] == 1:
                    model = CONRNN_mulin_main(N_Time, 2 * N_L_in, 2 * N_L_in, 8, fiter=3)
                else:
                    model = CNN_single_main_3(2 * N_L_in, 2 * N_L_in, 8)
            else:
                model = load_model(save_path)
            model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()

            if train == 1:
                # ----------------------------------------
                #  File path of the data set
                # -----------------------------------------
                path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleighsnr\strain\Cons'
                dataFile = path + '\Con_' + str(2 * N_L_in) + '_Ds' + str(DS_VEC[dd]) + '_' + str(num_tim) + '_' + str(
                    N_Time) + '_' + str(tra_totaln) + 'T_mod_CNN_' + str(SNRK) + 'kind_MUL_dB120_ruili_1.01sig_0.mat'
                # ------------------------------------------
                #  load train data
                # ------------------------------------------
                if net[jj] == 1 or net[jj] == 2:
                    [list1, output_train]=whether_slots_numpy_to_list(n_to_l=1,dataFile=dataFile,IQ=0,N_Time=N_Time)
                    print('Training ------------')
                    model.fit(list1, output_train, epochs=100, batch_size=80, validation_split=0.15, verbose=2,
                              shuffle=True, callbacks=[checkpoint])
                else:
                    [input_train, output_train] = whether_slots_numpy_to_list(n_to_l=0, dataFile=dataFile, IQ=0, N_Time=N_Time)
                    print('Training ------------')
                    model.fit(input_train, output_train, epochs=300, batch_size=300,  validation_split=0.15, verbose=2,
                              shuffle=True, callbacks=[checkpoint])

            else:
                print('there is not train ')






