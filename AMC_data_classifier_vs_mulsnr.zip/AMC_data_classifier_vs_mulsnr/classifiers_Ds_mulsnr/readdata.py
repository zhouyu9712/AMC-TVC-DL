import numpy as np
import scipy.io as scio
import h5py

#No application yet
def randi_hand(input,output):
    index = [i for i in range(len(input))]
    np.random.shuffle(index)
    input = input[index]
    output = output[index]
    return input, output
# load data by scipy
def mat_Sci_load(dataFile,IQ):

    data =scio.loadmat(dataFile)
    if IQ == 1:
        data_train_c = np.array(data['IQ_mulN_reieve_CNN'], dtype='float16')
    else:
        data_train_c = np.array(data['slotted_CD_reieve_CNN'], dtype='float16')
    input=np.transpose(data_train_c)
    output=np.array(data['output'],dtype='float32')
    return  input, output
# load data by h5py ;  IQ/slotted-CD/CD
def mat_h5py_load(dataFile,IQ):
    data = h5py.File(dataFile)
    if IQ==1:
        data_train_c = np.array(data['IQ_mulN_reieve_CNN'], dtype='float16')
        input = np.transpose(data_train_c, (2, 1, 0))
        output = np.transpose(np.array(data['output'], dtype='float16'))
        [input, output] = randi_hand(input, output)
    else:
        data_train_c = np.array(data['slotted_CD_reieve_CNN'], dtype='uint8')# float16; unit use to save resources
        input = np.transpose(data_train_c, (3, 2, 0, 1))
        output = np.transpose(np.array(data['output'], dtype='uint8'))
        [input, output] = randi_hand(input, output)

    return input, output

# load data/ slotted-CD/or CD; IQ=0
def whether_slots_numpy_to_list(n_to_l,dataFile,IQ,N_Time):
    [input_train, output_train] = mat_h5py_load(dataFile, IQ)
    #n_to_l==1: load slotted-CD; else load CD
    if n_to_l== 1:
        names = locals()
        for x in range(0, N_Time):
            names['In_put_tra_%s' % x] = np.zeros(
                [input_train.shape[0], 1, input_train.shape[2], input_train.shape[3]], dtype='float16')#float16 uint or float
            #names['In_put_tra_%s' % x][:, 0, :, :] = input_train[:, x, :, :] #/ np.max(input_train[xx, x, :, :])
            for xx in range (0,input_train.shape[0]):
                names['In_put_tra_%s' % x][xx, 0, :, :]=(input_train[xx, x, :, :])/np.max(input_train[xx, x, :, :])#0-255 to 0-1
        #/ np.max(input_train[:, x, :, :])
        list1 = [names['In_put_tra_%s' % x] for x in range(N_Time)]
        return list1, output_train  #  we need input list to MCBLDN
    else:
        return input_train,output_train

