clear ;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%test code for different segmentation strategy
%code for vs 8 modulation formals（BPSK，QPSK，8PSK，16QAM,32QAM,64QAM,128QAM,256QAM）
%1 System parameter configuration
%2 produce data
%3 raw IQ to gary image/slotted-CD
%4 save image/slotted-CD
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% param settting time-varying,awgn iq
Ds_vec              = [10,150];                                 %  Doppler shift parameter vector
N_SYMS1             = 36000;                                    %  Data length of one frame  
num_tim             = [400 600 1200 2000 4000 6000 8000 36000]; %  the data length of each slots vector 
R                   = [32,16];                                  %  the size of gary image /slotted-CD       
snr                 = (10);                                     %  Although there is only one value, in order to facilitate expansion
AWGN                = 0;                                        %  time-varying channel.AWGN is 0
IQ                  = 1;                                        %  IQ need to save ; Make sure the data source is the same
NUM_TOTAL           = 3000;                                     %  the number of frame
SNR_MUL             = 0;                                        %  Is SNR multiple
TH_S                = 120;                                      %  reduce noise;
ku                  = 1.01;                                     %  the boundary of the maximum amplitude of I\Q sampled signals 
%% cycle
for s=1:length(snr)                                             %  cycle for snr
    SNR_dB          = snr(s);
    for d=1:length(Ds_vec)                                      %  cycle for Doppler shift parameter vector                      
        D_S         = Ds_vec(d);
        %% produce source data
        N_SYMS                   = N_SYMS1;                     %  Data length of one frame
        N_KSNR                   = length(SNR_dB);              %  the number of SNR  /  test code  this is 1
        NUM_SDR                  = NUM_TOTAL/N_KSNR;            %  the number of frame for each SNR
        recive_symbols_frist    = zeros(N_SYMS,NUM_TOTAL,'single');
        for i=1:N_KSNR
            fprintf('the produce data SNR change as %d\n', SNR_dB(i));
            recive_symbols_frist(:,(i-1)*NUM_SDR+1:i*NUM_SDR)=sigcarrier_8mod_pro_time(N_SYMS,SNR_dB(i),NUM_SDR,D_S,AWGN);
        end
        %%  produce lable
        
        N_M                     = 8;                                      % Number of kinds of Modulation
        N_D                     = NUM_SDR/N_M;                                    % Number of total frame
        %lables                  = zeros(1,NUM_SDR);
        for i=1:1:N_M
            lables((i-1)*N_D +1:i*N_D)=i;
        end
        output_one = zeros(NUM_SDR , N_M);
        for i = 1:NUM_SDR
            output_one(i,lables(i) )=1;
        end
        
        for i=1:N_KSNR
            output(NUM_SDR*(i-1)+1:NUM_SDR*i,:)=output_one;
        end
        for rr=1:length(R)
            RR=R(rr);
            fprintf('the constelation image scale change as %d\n', 2*RR)
            %%  segmentation
            for nt=1:length(num_tim)
                fprintf('the num change as %d\n', num_tim(nt));
                NUM_Tim            = num_tim(nt);           % the data length of each slots
                N_SYMS             = N_SYMS1;               % Data length of one frame   
                N_Time             = floor(N_SYMS/NUM_Tim); % the number of slots
                NUM_Tim_new        = floor(N_SYMS/N_Time);  % updata the data length of each slots
                N_SYMS             = NUM_Tim_new*N_Time;    % updata data length of one frame
                N_L_in             = RR;                    % the size of gray image length
                N_W_in             = RR;                    % the size of gray image width
                
                receive_symbols      = zeros(N_SYMS,NUM_SDR);
                slotted_CD_reieve_CNN  = zeros(NUM_TOTAL,N_Time,2*N_L_in,2*N_W_in,'uint8');
                %%  IQ for compare 
                if (rr==1) && (IQ==1) && (nt==1)   % produce IQ only for once
                    NUM_Tim_IQ           = N_SYMS1;
                    N_Time_IQ            = floor(N_SYMS/NUM_Tim_IQ);       % N_Time_IQ is used to divide N_SYMS, N_Time_IQ often to 1
                    IQ_mulN_reieve_CNN   = zeros(NUM_TOTAL*N_Time_IQ,2,NUM_Tim_IQ ,'single');
                end
                %% for SNR
                for i=1:N_KSNR
                    fprintf('the SNR change as %d\n', SNR_dB(i));
                    receive_symbols(:,1:NUM_SDR)=recive_symbols_frist(1:N_SYMS,(i-1)*NUM_SDR+1:i*NUM_SDR); % Source IQ data assignment for each snr
                    receive_symbols_slot = reshape(receive_symbols,[NUM_Tim_new,N_Time,NUM_SDR]);          % reshape to multiple time slotts
                    if IQ==1  % Raw IQ data split / no split
                        receive_symbols_slot_IQ = reshape(receive_symbols,[NUM_Tim_IQ,N_Time_IQ,NUM_SDR]);
                    end
                    
                    for z=1: NUM_SDR
                        L_in=ku*max(abs(real(receive_symbols(:,z))));
                        W_in=ku*max(abs(imag(receive_symbols(:,z)))); % Determine the gray image boundary
                        for j=1:N_Time           % IQ is converted to the gray image /slotted-CD
                            slotted_CD_reieve_CNN((i-1)*NUM_SDR+z,j,:,:)=data_to_gram_int_find2(receive_symbols_slot(:,j,z),N_L_in,N_W_in,L_in,W_in,TH_S);
                        end
                        if (rr==1) && (IQ==1) && (nt==1)  % produce IQ only for once; reshape IQ for save
                            for pp=1: N_Time_IQ
                                IQ_mulN_reieve_CNN((pp-1)*NUM_TOTAL+(i-1)*NUM_SDR+z,1,:)  = real(receive_symbols_slot_IQ(:,pp,z));
                                IQ_mulN_reieve_CNN((pp-1)*NUM_TOTAL+(i-1)*NUM_SDR+z,2,:)  = imag(receive_symbols_slot_IQ(:,pp,z));
                            end
                        end
                    end
                end
                
                %% save data
                path='E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleigh_vs_Nst\stest';
                if (SNR_MUL == 1)
                    save (strcat(path,'\Cons\Con_',num2str(2*N_L_in),'_Ds',num2str(D_S),'_',num2str(NUM_Tim),...
                        '_',num2str(N_Time),'_',num2str(NUM_TOTAL/1000),'T_mod_CNN_',num2str(N_KSNR),'kind_MUL_dB',num2str(TH_S),'_ruili_',...
                        num2str(ku),'sig_uint8_1.mat'),'output','slotted_CD_reieve_CNN')
                else
                    save (strcat(path,'\Cons\Con_',num2str(2*N_L_in),'_Ds',num2str(D_S),'_',num2str(NUM_Tim),...
                        '_',num2str(N_Time), '_',num2str(NUM_TOTAL/1000),'T_mod_CNN_',num2str(N_KSNR),'kind_sin_',num2str(SNR_dB(1)),'_dB',...
                        num2str(TH_S),'ruli_',num2str(ku),'sig_uint8_1.mat'),'output','slotted_CD_reieve_CNN')
                end
                %%  save IQ data
                if (rr==1) && (IQ==1)
                    if (SNR_MUL == 1)
                        save (strcat(path,'\IQ_two\IQ_',num2str(2*N_L_in),'_Ds',num2str(D_S),'_',num2str(NUM_Tim_IQ ),...
                            '_',num2str(N_Time_IQ),'_',num2str(NUM_TOTAL*N_Time_IQ/1000),'T_mod_CNN_',num2str(N_KSNR),'kind_MUL_dB',num2str(TH_S),'_ruili_',...
                            num2str(ku),'sig_1.mat'),'output','IQ_mulN_reieve_CNN')
                    else
                        save (strcat(path,'\IQ_two\IQ_',num2str(2*N_L_in),'_Ds',num2str(D_S),'_',num2str(NUM_Tim_IQ ),...
                            '_',num2str(N_Time_IQ), '_',num2str(NUM_TOTAL*N_Time_IQ/1000),'T_mod_CNN_',num2str(N_KSNR),'kind_sin_',num2str(SNR_dB(1)),'_dB',...
                            num2str(TH_S),'ruli_',num2str(ku),'sig_1.mat'),'output','IQ_mulN_reieve_CNN')
                    end
                end
                
            end
        end
    end
end