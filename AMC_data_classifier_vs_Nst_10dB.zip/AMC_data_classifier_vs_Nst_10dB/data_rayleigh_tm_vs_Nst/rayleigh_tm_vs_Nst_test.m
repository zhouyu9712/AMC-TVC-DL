clear ;
%% param settting time-varying,awgn iq
Ds_vec=[10 150];
N_OFDM_SYMS1=36000;
num_tim=[400 600 1200 2000 4000 6000 8000 36000];
R=[32 ];
snr=10;
AWGN=0;
%% cycle
for s=1:length(snr)
    %num_tim=(2000:2000:10000);
    for d=1:1:length(Ds_vec)
        NUM_TOTAL          = 3000;
        SNR_MUL            = 0;
        TH_S               = 120;    %reduce noise;
        D_S                = Ds_vec(d);
        ku                 = 1.01;
        SNR_dB             = snr(s);
        %% produce source data
        N_OFDM_SYMS        = N_OFDM_SYMS1;
        N_KSNR             = length(SNR_dB);
        NUM_SDR            = NUM_TOTAL/N_KSNR;
        CFO_nocp_reieve_frist    = zeros(N_OFDM_SYMS,NUM_TOTAL);
        for i=1:N_KSNR
            fprintf('the produce data SNR change as %d\n', SNR_dB(i));
            CFO_nocp_reieve_frist(:,(i-1)*NUM_SDR+1:i*NUM_SDR)=sigcarrier_8mod_pro_time(N_OFDM_SYMS,SNR_dB(i),NUM_SDR,D_S,AWGN);
        end
        %%  produce lable
        
        N_M                     = 8;                                      % Number of kinds of Modulation
        N_D                     = NUM_SDR/N_M;                                    % Number of total frame
        %lables                  = zeros(1,NUM_SDR);
        for i=1:1:N_M
            lables((i-1)*N_D +1:i*N_D)=i;
        end
        output_one = zeros(NUM_SDR , N_M);
        for i = 1:NUM_SDR
            output_one(i,lables(i) )=1;
        end
        
        for i=1:N_KSNR
            output(NUM_SDR*(i-1)+1:NUM_SDR*i,:)=output_one;
        end
        for qq=1:length(R)
            RR=R(qq);
            fprintf('the constelation image scale change as %d\n', 2*RR)
            %%  segmentation
            for ss=1:length(num_tim)
                fprintf('the num change as %d\n', num_tim(ss));
                NUM_Tim            = num_tim(ss);
                N_OFDM_SYMS        = N_OFDM_SYMS1;
                N_Time             = floor(N_OFDM_SYMS/NUM_Tim);
                NUM_Tim_new        = floor(N_OFDM_SYMS/N_Time);
                N_OFDM_SYMS        = NUM_Tim_new*N_Time;
                N_L_in             = RR;
                N_W_in             = N_L_in;
                
                CFO_nocp_reieve      = zeros(N_OFDM_SYMS,NUM_SDR);
                CFO_nocp_reieve_CNN  = zeros(NUM_TOTAL,N_Time,2*N_L_in,2*N_W_in,'single');
                %%
                for i=1:N_KSNR
                    fprintf('the SNR change as %d\n', SNR_dB(i));
                    CFO_nocp_reieve(:,1:NUM_SDR)=CFO_nocp_reieve_frist(1:N_OFDM_SYMS,(i-1)*NUM_SDR+1:i*NUM_SDR);
                    %load('E:\gradeone_work\honorway\data_sigc\symbol=1024_0.8W_8_fre_sigc_10dB.mat')
                    CFO_nocp_reieve_Time = reshape(CFO_nocp_reieve,[NUM_Tim_new,N_Time,NUM_SDR]);

                    
                    for z=1: NUM_SDR
                        L_in=ku*max(abs(real(CFO_nocp_reieve(:,z))));
                        W_in=ku*max(abs(imag(CFO_nocp_reieve(:,z))));
                        for j=1:N_Time
                            CFO_nocp_reieve_CNN((i-1)*NUM_SDR+z,j,:,:)=data_to_gram(CFO_nocp_reieve_Time(:,j,z),N_L_in,N_W_in,L_in,W_in,TH_S);
                        end      
                    end
                end
                
                %% save data
                if (SNR_MUL == 1)
                    save (strcat('E:\gradetwo_work\mod_cla_mat\sig_car_tim_vary\dataa_time\sn_no_vary\stest\sNLv_s_36\Con_',num2str(2*N_L_in),'_Ds',num2str(D_S),'_',num2str(NUM_Tim),...
                        '_',num2str(N_Time),'_',num2str(NUM_TOTAL/1000),'T_mod_CNN_',num2str(N_KSNR),'kind_MUL_dB',num2str(TH_S),'_ruili_',...
                        num2str(ku),'sig2.mat'),'output','CFO_nocp_reieve_CNN')
                else
                    save (strcat('E:\gradetwo_work\mod_cla_mat\sig_car_tim_vary\dataa_time\sn_no_vary\stest\sNLv_s_36\Con_',num2str(2*N_L_in),'_Ds',num2str(D_S),'_',num2str(NUM_Tim),...
                        '_',num2str(N_Time), '_',num2str(NUM_TOTAL/1000),'T_mod_CNN_',num2str(N_KSNR),'kind_sin_',num2str(SNR_dB(1)),'_dB',...
                        num2str(TH_S),'ruli_',num2str(ku),'sig2.mat'),'output','CFO_nocp_reieve_CNN')
                end
                
            end
        end
    end
end