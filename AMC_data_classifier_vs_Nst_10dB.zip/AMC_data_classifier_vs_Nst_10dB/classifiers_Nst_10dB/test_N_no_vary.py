# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model, load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from hard_judge import *
from readdata import *
# -----------------------------------------
# parameter setting
# -----------------------------------------
N_SYMS1     = 36000               #  Data length of one frame
DS_VEC      = [10,150]            #  Doppler shift parameter vector; 10 or 150
net_vec     = [1,2]               #  net=1:MCBLDN; net=2:SCDN
SNR         = 10                  #  SNR is fixed at 10dB
tes_totaln = 3                    #  the number of test frame
RR = 32                           #  R resolution ; complexity
# -----------------------------------------
# test process for 3 cycle
# 1. different classifiers
# 2. different doppler shift
# 3. different segmentation strategy
# -----------------------------------------
for nn in range (0,len(net_vec),1):           # cycle for classifiers
    net=net_vec[nn]
    if net == 1:
        num_tim = [400, 600, 1200, 2000,4000,6000,9000]  # the data length of each slots vector for fading channels
    else:
        num_tim = [N_SYMS1]

    for z in range(0, len(DS_VEC), 1):        # cycle for doppler shift
        Ds = DS_VEC[z]
        # -----------------------------------------
        # Initialize variables for storage
        # -----------------------------------------
        accuracy = np.zeros([1, len(num_tim)])    # save accuracy for each segmentation strategy
        matrix = np.zeros([len(num_tim), 8, 8])   # save detail modulation formats accuracy for each segmentation strategy
        for i in range(0, len(num_tim), 1):       # cycle for each segmentation strategy
            N_Time = math.floor(N_SYMS1/ num_tim[i])
            # -----------------------------------------
            # File path of saved model
            # -----------------------------------------
            if net == 1:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_Nst\MCCBLDN\DS_" + str(
                    Ds) + "\stmp_Ds_" + str(Ds) + "_R_" + str(2 * RR ) + "_SNR_" + str(SNR) + "_cnn2_L" + str(
                    N_Time) + "_N" + str(int(num_tim[i] / 100)) + ".h5"
            else:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_Nst\SCDN\DS_" + str(
                            Ds) + "\stmp_Ds" + str(Ds) + "_R_" + str(2 * RR ) + "_SNR_" + str(SNR) + "_scnn_L" + \
                                    str(N_Time) + "_N" + str(int(num_tim[i] / 100)) + ".h5"
            checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)
            # -----------------------------------------
            # load model
            # -----------------------------------------
            model = load_model(save_path)
            model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()

            # ---------------------------------------------------
            # load new data for test; File path of the data set
            # ---------------------------------------------------
            path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleigh_vs_Nst\stest\Cons'
            dataFiletest = path + '\Con_' + str(2 * RR) + '_Ds' + str(Ds) + '_' + str(num_tim[i]) + '_' + str(
                N_Time) + '_' + str(tes_totaln) + 'T_mod_CNN_1kind_sin_10_dB120ruli_1.01sig_uint8.mat'
            # load test data and evaluate
            if net == 1:
                [list1, output_train] = whether_slots_numpy_to_list(n_to_l=1, dataFile=dataFiletest, IQ=0,N_Time=N_Time)
                print('\nTesting ------------')
                loss, accuracy[0, i] = model.evaluate(list1, output_train)
                matrix[i, :, :] = Modu_ways_statistics(list1, model, output_train)
            else:
                [input_train, output_train] = whether_slots_numpy_to_list(n_to_l=0, dataFile=dataFiletest, IQ=0,N_Time=N_Time)
                print('\nTesting ------------')
                loss, accuracy[0, i] = model.evaluate(input_train, output_train)
                matrix[i, :, :] = Modu_ways_statistics(input_train, model, output_train)
            print('Identification matrix:\n', matrix)
            print('test loss: ', loss)
            print('test accuracy: ', accuracy)

        # scio.savemat(dataNew, {'acc1':accuracy, }) save accuracy and matrix
        dataNew = 'F:\matlab\plot_data\Paper\DS_10_150_VS_Nst\Ds' + str(Ds)+'_' + str(N_SYMS1 ) \
                  + 'R_'+str(2*RR)+'net_' + str(net) + '_1.mat'
        scio.savemat(dataNew, {'acc': accuracy, 'matrix': matrix})







