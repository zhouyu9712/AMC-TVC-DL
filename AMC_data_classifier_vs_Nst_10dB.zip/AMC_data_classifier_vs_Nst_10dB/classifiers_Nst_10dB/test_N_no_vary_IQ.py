# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model,load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from hard_judge import *
from readdata import *
# -----------------------------------------
# parameter setting
# -----------------------------------------
N_L_in        =  32                                     #  only for load test data
net           =  3                                      #  net=1:MCBLDN; net=2:SCDN 3: ResNet
DS_VEC        =  [10,150]                               #  Doppler shift parameter vector; 0:AWGN
SNRK          =  10                                     #  SNR is fixed at 10dB
tra_totaln    = 48                                      #  the number of train frame
N_OFDM_SYMS = 36000                                     #  Data length of one frame
num_tim = N_OFDM_SYMS                                   #  there is no slotted
N_Time = math.floor(N_OFDM_SYMS / num_tim)              #  This variable is optional ,  only for unified mark
# -----------------------------------------
# testing process for 1 cycle
# 1. different doppler shift
# -----------------------------------------
for dd in range(0,len(DS_VEC),1):       # cycle for doppler shift
    Ds = DS_VEC[dd]

    # -----------------------------------------
    # File path of saved model
    # -----------------------------------------
    save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_Nst\IQ_RN\DS_"+str(Ds)+"\stmp_Ds"+str(
        Ds)+"snr"+str(SNRK)+"_scnn_L1_N" + str(int(num_tim / 100)) + "_"+str(tra_totaln)+"_0.80.h5"
    checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)
    # -----------------------------------------
    # load model
    # -----------------------------------------
    model = load_model(save_path)
    model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    model.summary()
    # -----------------------------------------
    # Initialize variables for storage
    # -----------------------------------------
    snr=np.linspace(SNRK, SNRK,1,endpoint=True, dtype='int8')
    accuracy = np.zeros([1, len(snr)])
    matrix = np.zeros([len(snr), 8, 8])
    # ------------------------------------
    # load new data for test; File path of the data set
    # ------------------------------------
    path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleigh_vs_Nst\stest\IQ_two'
    for i in range(len(snr)):
        dataFiletest = path + '\IQ_' + str(2 * N_L_in) + '_Ds'+ str(Ds) +'_' + str(num_tim) + '_' + str(N_Time) + \
                       '_3T_mod_CNN_1kind_sin_' + str(snr[i]) + '_dB120ruli_1.01sig.mat'

        [input_two, output_two] = mat_h5py_load(dataFiletest, IQ=1)

        print('\nTesting ------------')
        # load test data and evaluate
        loss, accuracy[0, i] = model.evaluate(input_two, output_two) # Test model to obtain classification accuracy
        matrix[i, :, :] = Modu_ways_statistics(input_two, model, output_two)

        print('Identification matrix:\n', matrix[i, :, :])
        print('test loss: ', loss)
        print('the snr is ', snr[i])
        print('test accuracy: ', accuracy[0, i])
    print('test accuracy: ', accuracy)

    # scio.savemat(dataNew, {'acc1':accuracy, }) save accuracy and matrix
    dataNew = 'F:\matlab\plot_data\Paper\DS_10_150_VS_Nst\sDs'+str(Ds)+'IQ'+str(N_OFDM_SYMS) +'net' + str(net)+'_' + str(N_Time) + 'format' + str(
        2 * N_L_in) + '.mat'
    scio.savemat(dataNew, {'acc': accuracy, 'matrix': matrix})


