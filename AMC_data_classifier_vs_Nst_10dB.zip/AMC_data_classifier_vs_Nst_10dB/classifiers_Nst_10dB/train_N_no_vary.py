# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model, load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from readdata import *
# -----------------------------------------
# parameter setting
# -----------------------------------------
DS_VEC = [10,150]                      #  Doppler shift parameter vector; 0:AWGN
N_SYMS1    = 36000                     #  Data length of one frame
RR=[32]                                #  R resolution ; complexity
net_vec=[1,2]                          #  net=1:MCBLDN; net=2:SCDN
SNR=10                                 #  SNR is fixed at 10dB
filter = 3                             #  the number of Convolutional filter in MCBLDN
tra_totaln = 48                        #  the number of frame
# -----------------------------------------
# training process for 4 cycle
# 1. different resolution
# 2. different classifiers
# 3. different doppler shift
# 4. different segmentation strategy
# -----------------------------------------
for rr in range(0,len(RR),1):          #  cycle for resolution
    N_L_in=RR[rr]
    for nn in range(0, len(net_vec), 1): #  cycle for classifiers
        net = net_vec[nn]
        if net == 1:
            num_tim = [9000,600,1200,2000,4000,6000,9000]  # the data length of each slots vector for fading channels
        else:
            num_tim = [N_SYMS1 ]
        for z in range(0, len(DS_VEC), 1):  #  cycle for doppler shift
            Ds = DS_VEC[z]
            if Ds == 150:
                epch = 240
            else:
                epch = 120

            for i in range(0, len(num_tim), 1): #  cycle for segmentation strategy
                N_Time = math.floor(N_SYMS1  / num_tim[i])
                First_train = True
                train = 1
                # -----------------------------------------------------------------
                # when you are using train=0, please make frist_train=false
                # -----------------------------------------------------------------
                if train == 0 :
                    First_train = False
                # -----------------------------------------
                # path of saved model
                # -----------------------------------------
                if net == 1:
                    save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_Nst\MCCBLDN\DS_" + str(
                        Ds) + "\stmp_Ds_" + str(Ds) + "_R_" + str(2 * N_L_in) + "_SNR_" + str(SNR) + "_cnn2_L" + str(
                        N_Time) + "_N" + str(int(num_tim[i] / 100)) + ".h5"
                else:

                    save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_Nst\SCDN\DS_" + str(
                        Ds) + "\stmp_Ds" + str(Ds) + "_R_" + str(2 * N_L_in) + "_SNR_" + str(SNR) + "_scnn_L" \
                                + str(N_Time) + "_N" + str(int(num_tim[i] / 100)) + ".h5"

                checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)
                # -----------------------------------------
                # creat model/ load saved model
                # -----------------------------------------
                if First_train == True:
                    if net == 1:
                        model = CONRNN_mulin_main(N_Time, 2 * N_L_in, 2 * N_L_in, 8, filter)
                    else:
                        model = CNN_single_main_3(2 * N_L_in, 2 * N_L_in, 8)
                else:
                    model = load_model(save_path)
                model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
                model.summary()

                if train == 1:
                    # ----------------------------------------
                    # File path of the data set
                    # -----------------------------------------
                    path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleigh_vs_Nst\strain\Cons'

                    dataFile = path + '\Con_' + str(2 * N_L_in) + '_Ds' + str(Ds) + '_' + str(
                        num_tim[i]) + '_' + str(N_Time) + '_' + str(tra_totaln) + 'T_mod_CNN_1kind_sin_' + str(
                        SNR) + '_dB120ruli_1.01sig_0.mat'
                    # ------------------------------------------
                    #  load train data
                    # ------------------------------------------
                    if net == 1:
                        [list1, output_train] = whether_slots_numpy_to_list(n_to_l=1, dataFile=dataFile, IQ=0,
                                                                            N_Time=N_Time)
                        print('Training ------------')
                        model.fit(list1, output_train, epochs=60, batch_size=60, validation_split=0.15, verbose=2,
                                  shuffle=True, callbacks=[checkpoint])
                    else:
                        [input_train, output_train] = whether_slots_numpy_to_list(n_to_l=0, dataFile=dataFile, IQ=0,
                                                                                  N_Time=N_Time)
                        print('Training ------------')
                        model.fit(input_train, output_train, epochs=100, batch_size=300, validation_split=0.15,
                                  verbose=2,shuffle=True, callbacks=[checkpoint])
                else:
                    print('there is not train ')
















