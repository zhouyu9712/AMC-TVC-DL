import numpy as np

#No application yet
def Model_predict_OFDM(inputdata,model):
    predict=np.ones([inputdata.shape[0],inputdata.shape[1]])
    data=np.ones([1,1,inputdata.shape[2],inputdata.shape[3]])
    for i in range(inputdata.shape[0]):
        for j in range(inputdata.shape[1]):
            data[0,0,:,:]=inputdata[i,j,: ,:]
            predict_test = model.predict(data)
            predict[i,j] = np.argmax(predict_test, axis=1)
    return predict
#No application yet
def showmax(lt):
    index1 = 0
    max = 0
    for i in range(len(lt)):
        flag = 0
        for j in range(i + 1, len(lt)):
            if lt[j] == lt[i]:
                flag += 1
        if flag > max:
            max = flag
            index1 = i
    return lt[index1]
#No application yet
def caclu_accuracy(predict,output):
    lables = np.ones([predict.shape[0]])
    fact_lables = np.argmax(output, axis=1)
    for i in range(predict.shape[0]):
        lables[i]=showmax(predict[i, :])
    accuracy = sum(lables == fact_lables)/predict.shape[0]
    #num = (str(accuracy.tolist()).count("1"))/predict.shape[0]
    return accuracy

# detailed classification case among eight modulation formats
def Modu_ways_statistics(list,model,output):
    matrix= np.zeros([8,8])
    predict_test = model.predict(list)
    # find max to determine what kind modulation
    predict = np.argmax(predict_test, axis=1)
    fact_lables = np.argmax(output, axis=1)
    for i in range(output.shape[0]):
        a=fact_lables[i]
        b=predict[i]
        matrix[a,b]=matrix[a,b]+1
    return matrix

# detailed classification case among four modulation formats
def Modu_ways_statistics_4_4(list,model,output):
    matrix= np.zeros([4,4])
    predict_test = model.predict(list)
    predict = np.argmax(predict_test, axis=1)
    fact_lables = np.argmax(output, axis=1)
    for i in range(output.shape[0]):
        a=fact_lables[i]
        b=predict[i]
        matrix[a,b]=matrix[a,b]+1
    return matrix