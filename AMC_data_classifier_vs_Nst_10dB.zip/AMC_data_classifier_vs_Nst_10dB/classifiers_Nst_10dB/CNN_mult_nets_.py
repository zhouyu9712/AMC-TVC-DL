from keras.layers import *
from keras.models import Model, Sequential
from keras.layers import Concatenate,add
import math
K.set_learning_phase(0)

#------------------------------------------------------------
# Functional formula
#------------------------------------------------------------
def CNN_single_main_3(input_dim1,input_dim2, output_dim):
# input
    inputs=Input(shape=(1,input_dim1,input_dim2))
# Conv layer 1 output shape (8, input_dim1/2, input_dim2/2)
    Conv1=Convolution2D( filters=8, kernel_size=3, strides=1, padding='same',data_format='channels_first',activation='relu')(inputs)
# Pooling layer 1 (max pooling) output shape
    Maxp1=MaxPooling2D( pool_size=2, strides=2, padding='same', data_format='channels_first')(Conv1)
# Conv layer 2 output shape
    Conv2=Convolution2D(16, 3, strides=1, padding='same', data_format='channels_first',activation='relu')(Maxp1)
#  dropout 0.2
    Drop1=Dropout(0.2)(Conv2)
# Pooling layer 2 (max pooling) output shape (
    Maxp2=MaxPooling2D(2, 2, 'same', data_format='channels_first')(Drop1)
# Conv layer 3 output shape
    Conv3=Convolution2D(32, 2, strides=1, padding='same', data_format='channels_first',activation='relu')(Maxp2)
#dropout 0.2
    Drop2=Dropout(0.2)(Conv3)
    Maxp3=MaxPooling2D(2, 2, 'same', data_format='channels_first')(Drop2)
# Pooling layer 3 (max pooling) output shape
    Conv4 = Convolution2D(16, 2, strides=1, padding='same', data_format='channels_first', activation='relu')(Maxp3)
    Drop3=Dropout(0.2)(Conv4)

# Fully connected layer 1 input shape (16 * input_dim1/8 * input_dim2/8)  output shape (1024)
    Fla1=Flatten()(Drop3)
    Den1=Dense(1024,activation='relu')(Fla1)
    Dorp5=Dropout(0.2)(Den1)
#  dense2
    Den2 = Dense(256, activation='relu',kernel_regularizer=regularizers.l2(0.01))(Dorp5)
    Dorp6 = Dropout(0.2)(Den2)
#  dense3
    Den3 = Dense(64, activation='relu',kernel_regularizer=regularizers.l2(0.01))(Dorp6)
    Dorp7 = Dropout(0.2)(Den3)

    output=Dense(output_dim,activation='softmax',kernel_regularizer=regularizers.l2(0.01))(Dorp7)
    model=Model(inputs=inputs,outputs=output)
    return model

def CONRNN_mulin_main(input_dim_c,input_dim1,input_dim2, output_dim, fiter):
# filter parameters
    fiter1 = fiter
    fiter2 = 2*fiter
    fiter3 = fiter
# input
    names = locals()
    for i in range(0,input_dim_c):
        names['In_put_tra_%s' %i]=Input(shape=(1,input_dim1,input_dim2),name='input_tra_'+str(i))

    list1 = [names['In_put_tra_%s' % i] for i in range(input_dim_c)]
# multiple parallel CNNs
    for i in range(0,input_dim_c):
        names['Conv%s_1' %i] = Convolution2D(filters=fiter1, kernel_size=3, strides=1, padding='same', data_format='channels_first',activation='relu')(names['In_put_tra_%s' %i])
        names['Maxp%s_1' %i] = MaxPooling2D(pool_size=2, strides=2, padding='same', data_format='channels_first')(names['Conv%s_1' %i])

        names['Conv%s_2' %i] = Convolution2D(fiter2, 3, strides=1, padding='same', data_format='channels_first', activation='relu')(names['Maxp%s_1' %i])
        names['Maxp%s_2' %i] = MaxPooling2D(2, 2, 'same', data_format='channels_first')(names['Conv%s_2' %i])

        names['Conv%s_3' %i] = Convolution2D(fiter3, 2, strides=1, padding='same', data_format='channels_first', activation='relu')(names['Maxp%s_2' %i])
        names['Maxp%s_3' %i] = MaxPooling2D(2, 2, 'same', data_format='channels_first')(names['Conv%s_3' %i])
        # Fully connected layer 1 input shape (64 * 7 * 7) = (3136), output shape (1024)
        names['Fla%s' % i]   = Flatten()(names['Maxp%s_3' %i])

    j=0
    Fla1_reshape = names['Fla%s' % j]
# Concatenate
    for i in range(1, input_dim_c):
        Fla1_reshape = Concatenate(axis=1)([Fla1_reshape , names['Fla%s' %i]] )
# Reshape
    Fla1_reshape1 = Reshape(target_shape=(input_dim_c, int(fiter3* math.ceil(input_dim1/8)*math.ceil(input_dim2/8))))(Fla1_reshape)
#  bidirectional long short-term memory network
    lstm_1 = LSTM(64, return_sequences=True, kernel_initializer='he_normal', name='lstm1', dropout=0.5)(Fla1_reshape1)  # (None, 32, 512)
    lstm_1b = LSTM(64, return_sequences=True, go_backwards=True, kernel_initializer='he_normal', name='lstm1_b',dropout=0.5)(Fla1_reshape1)

    reversed_lstm_1b = Lambda(lambda inputTensor: K.reverse(inputTensor, axes=1))(lstm_1b)
# add
    lstm1_merged = add([lstm_1, reversed_lstm_1b])  # (None, 32, 512)
    Fla3 = Flatten()(lstm1_merged)
#DNN
    Den1 = Dense(32, activation='relu', kernel_regularizer=regularizers.l2(0.01))(Fla3)
    Dorp3 = Dropout(0.2)(Den1)

    Den2 = Dense(16, activation='relu', kernel_regularizer=regularizers.l2(0.01))(Dorp3)
    Dorp4 = Dropout(0.2)(Den2)
    output = Dense(output_dim, activation='softmax', kernel_regularizer=regularizers.l2(0.01))(Dorp4)
    model = Model(inputs=list1, outputs=output)
    return model

# ResNet for IQ /time windows is 1024
def res_block_v2(x, output_filter):
    #  one Residual Stack, reduce by 2
    res_x = BatchNormalization()(x)
    res_x = Activation('relu')(res_x)
    res_x = Conv1D(filters=output_filter, kernel_size=(2), strides=2, padding='same',data_format='channels_first')(res_x)
    Dorp1 = Dropout(0.5)(res_x)

    res_x = BatchNormalization()(Dorp1)
    res_x = Activation('relu')(res_x)
    res_x = Conv1D(filters=output_filter, kernel_size=(2), strides=1, padding='same',data_format='channels_first')(res_x)
    Dorp2 = Dropout(0.5)(res_x)

    identity = Conv1D(filters=output_filter, kernel_size=(1),  strides=2, padding='same',data_format='channels_first')(x)
    output= add([identity, Dorp2])
    return output
def resnet_IQ(input_dim, output_dim):
    # ResNet six block
    inputs = Input(shape=( 2,input_dim))
    x = Conv1D(kernel_size=(2), filters=32 , strides=1, padding='same', activation='relu',data_format='channels_first')(inputs)
    x = res_block_v2(x,  32)
    x = res_block_v2(x,  32)
    x = res_block_v2(x,  32)
    x = res_block_v2(x,  32)
    x = res_block_v2(x,  32)
    x = res_block_v2(x,  32)
    x = BatchNormalization()(x)
    y = Flatten()(x)

    Den1 = Dense(128, activation='relu')(y)
    Dorp3 = Dropout(0.2)(Den1)
    #  dense2
    Den2 = Dense(128, activation='relu')(Dorp3)
    Dorp4 = Dropout(0.2)(Den2)
    #  dense3
    outputs = Dense(output_dim, activation='softmax', kernel_initializer='he_normal')(Dorp4)
    model = Model(inputs=inputs, outputs=outputs)
    return model

# ResNet for IQ /time windows is 36000
def res_block_v2_for36(x, output_filter):
    #  one Residual Stack, reduce by 4
    res_x = BatchNormalization()(x)
    res_x = Activation('relu')(res_x)
    res_x = Conv1D(filters=output_filter, kernel_size=(2), strides=2, padding='same',data_format='channels_first')(res_x)
    Dorp1 = Dropout(0.5)(res_x)

    res_x = BatchNormalization()(Dorp1)
    res_x = Activation('relu')(res_x)
    res_x = Conv1D(filters=output_filter, kernel_size=(2), strides=2, padding='same',data_format='channels_first')(res_x)
    Dorp2 = Dropout(0.5)(res_x)

    identity = Conv1D(filters=output_filter, kernel_size=(4),  strides=4, padding='same',data_format='channels_first')(x)
    output= add([identity, Dorp2])
    return output
def resnet_IQ_for36(input_dim, output_dim):
    # ResNet six block
    inputs = Input(shape=( 2,input_dim))
    x = Conv1D(kernel_size=(2), filters=32 , strides=2, padding='same', activation='relu',data_format='channels_first')(inputs)
    x = res_block_v2_for36(x, 32)
    x = res_block_v2_for36(x, 32)
    x = res_block_v2_for36(x, 32)
    x = res_block_v2_for36(x, 32)
    x = res_block_v2_for36(x, 32)
    x = res_block_v2_for36(x, 32)
    x = BatchNormalization()(x)
    y = Flatten()(x)

    Den1 = Dense(128, activation='relu')(y)
    Dorp3 = Dropout(0.2)(Den1)
    #  dense2
    Den2 = Dense(128, activation='relu')(Dorp3)
    Dorp4 = Dropout(0.2)(Den2)
    #  dense3
    outputs = Dense(output_dim, activation='softmax', kernel_initializer='he_normal')(Dorp4)
    model = Model(inputs=inputs, outputs=outputs)
    return model