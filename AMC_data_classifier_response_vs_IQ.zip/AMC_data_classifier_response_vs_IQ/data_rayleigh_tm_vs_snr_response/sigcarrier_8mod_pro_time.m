function [raw_IQ_reieve] = sigcarrier_8mod_pro_time(N_DATA_SYMS1,SNR_dB1,XUNHUAN1,D_S,AWGN)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% produce equivalent baseband source IQ data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Waveform params
warning off
N_DATA_SYMS             = N_DATA_SYMS1;       % Number of data symbols ; Data length of one frame
MOD_ORDER               = 2;                  % Modulation order (2/4/16 = BSPK/QPSK/16-QAM)
N_K                     = 8;                  % the number of modulation formals

XUNHUAN                 = XUNHUAN1;           % the number of frame
XUNHUAN_S               = ceil(XUNHUAN/N_K);  % the number of frame for one kind modulation formal
%
fs                      = 10e4;               % bandwidth
%
SNR_dB                  = SNR_dB1;            % SNR  for dB
SNR_EB                  = 10.^(SNR_dB/10);    % SNR



raw_IQ_reieve_total=zeros(N_DATA_SYMS,XUNHUAN);
i=0;
while(i<XUNHUAN)
    %%   modulation
    tx_data = randi(MOD_ORDER, 1, N_DATA_SYMS) - 1;
    i=i+1; 
    switch MOD_ORDER
        case 2         % BPSK
            tx_syms=  pskmod(tx_data,MOD_ORDER);
        case 4         % QPSK
            tx_syms = pskmod(tx_data,MOD_ORDER);
        case 8         % 8PSK
            tx_syms = pskmod(tx_data,MOD_ORDER);
        case 16        % 16-QAM
            tx_syms = qammod(tx_data,MOD_ORDER);%
        case 32        % 32-QAM
            tx_syms = qammod(tx_data,MOD_ORDER);%
        case 64        % 64-QAM
            tx_syms = qammod(tx_data,MOD_ORDER);%
        case 128       % 128-QAM
            tx_syms = qammod(tx_data,MOD_ORDER);%
        case 256       % 256-QAM
            tx_syms = qammod(tx_data,MOD_ORDER);%
        otherwise
            fprintf('Invalid MOD_ORDER (%d)!  Must be in [2-256,2^n]\n', MOD_ORDER);
            continue;
    end
    tx_syms =  tx_syms./sqrt(mean(abs(tx_syms).^2));  %Power normalization
    
    SNR_ES=SNR_EB*log2(MOD_ORDER);                    % EB to ES
    
    
%% channel
    if AWGN==1 % awgn
        rx_vec_air         =  tx_syms + complex(randn(1,length(tx_syms)), randn(1,length(tx_syms)))/sqrt(SNR_ES*2);
    else       % time-varying channel
        switch D_S         %  the value of doppler shift
            case 5         %   v
                D_s                =   randi([5*10,15*10],1)./10;
            case 10         %  v
                D_s                =   randi([D_S*10,30*10],1)./10;
            case 40         %  v
                D_s                =   randi([D_S,120],1);
            case 150         % v
                D_s                =   randi([D_S,300],1);
            otherwise
                fprintf('it is wrong (%d)!  Must be in [10 50 150]\n',  D_S);
                continue;
        end
        rayleigh_channel   =  comm.RayleighChannel('SampleRate',fs ,'MaximumDopplerShift',D_s);
        [rx_vec_chan]      =  rayleigh_channel(tx_syms.');
        rx_vec_air         =  rx_vec_chan.' + complex(randn(1,length(tx_syms)), randn(1,length(tx_syms)))/sqrt(SNR_ES*2);
    end
   
    %% change modulation formal
    switch floor(i/XUNHUAN_S)
        case 0
            MOD_ORDER=2;
        case 1
            MOD_ORDER=4;
        case 2
            MOD_ORDER=8;
        case 3
            MOD_ORDER=16;
        case 4
            MOD_ORDER=32;
        case 5
            MOD_ORDER=64;
        case 6
            MOD_ORDER=128;
        case 7
            MOD_ORDER=256;
        otherwise
      %      fprintf('Invalid MOD_ORDER (%d)!  Must be in [2-256 2^n]\n', MOD_ORDER);
            % save ('abc.mat','CFO_nocp_reieve');         
    end
    
%     if mod(i,XUNHUAN_S)==0
%         fprintf('MOD_ORDER_changed as %d\n', MOD_ORDER);
%     end
    
    
    raw_IQ_reieve_total(:,i)=rx_vec_air();
    if mod(i,200)==0
        fprintf('we are doing the  %dth cycle\n', i);
    end
    
    
    if (mod(i,XUNHUAN)==0)
        b=floor(i/XUNHUAN);
        raw_IQ_reieve=raw_IQ_reieve_total(:,1:b*XUNHUAN); % Source IQ data assignment
      
 %       fprintf('the length of save data is %d\n', b*XUNHUAN)
    end
end