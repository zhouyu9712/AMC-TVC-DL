function   [gram] = data_to_gram_int_find2(data_in,N_L_in,N_W_in,L_in,W_in,Th_s)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% IQ is converted to the gray image /slotted-CD
% 2 is not normalized
% ps:unit8: 0-255, the number of points in each cell does not exceed 255
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Th=Th_s; % Invalid variable
data=data_in;
data_real=real(data);
data_imag=imag(data);
N_L=N_L_in;
N_W=N_W_in;
L=L_in;
W=W_in;
a=(-N_L:1:N_L);
b=(-N_W:1:N_W);
gram=zeros(2*N_L,2*N_W);

    %% seek for row
        [~ ,lo_real]=ismember (floor(N_L.*data_real./L),a);   
    %%
        [~ ,lo_imag]=ismember (floor(N_W.*data_imag./W),b);

for i=1:length(lo_real)
    gram(lo_real(i),lo_imag(i))=gram(lo_real(i),lo_imag(i))+1;
end

% M_ax=max(max(gram));
% if (Th<80)
% gram(gram<=(M_ax/Th))=0; % reduce noise data ( we delete it)
% end
% gram=gram./M_ax;
% Gray image is not normalized







