# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model,load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from hard_judge import *
from readdata import *
# -----------------------------------------
# parameter setting
# -----------------------------------------
N_L_in = 22                                    #  only for load test data
net=[1]                                        #  net=1:MCBLDN; net=2:SCDN 3: ResNet
Ds=10                                          #  Doppler shift ; 0:AWGN 10:doppler shift
SNRK=15                                        #  Number of SNR types 0:14
tra_totaln=240                                 #  the number of train frame
N_SYMS1 = 1024                                 #  Data length of one frame 1024/2048/4096
# -----------------------------------------
# testing process for 1 cycle
# 1. different classifier
# -----------------------------------------
for jj in range(0,len(net),1):
    if net[jj] == 1:
        num_tim = 1024                         # the number of each slot, 512/1024/2048/4096
    else:
        num_tim = N_SYMS1
    N_Time = math.floor(N_SYMS1 / num_tim)     #  the number of slottes
    # -----------------------------------------
    # File path of saved model
    # -----------------------------------------
    if net[jj] == 1:
        save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\RESPONSE\Eightmod_vs_IQ\MCCBLDN\DS_" + str(Ds) + "\stmp_Ds" + str(
            Ds) + "_crnn_R" + str(2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(int(num_tim))+"To" +str(tra_totaln)+ ".h5"

    else:
        save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\RESPONSE\Eightmod_vs_IQ\SCDN\DS_" + str(Ds) + "\stmp_Ds"\
            + str(Ds)+"_scnn_R" + str(2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(int(num_tim)) + ".h5"
    checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)

    # -----------------------------------------
    # load model
    # -----------------------------------------

    model = load_model(save_path)
    model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    model.summary()
    # -----------------------------------------
    # Initialize variables for storage
    # -----------------------------------------
    snr = np.linspace(0, SNRK - 1, SNRK, endpoint=True, dtype='int8')  # snr vector
    accuracy = np.zeros([1, len(snr)])
    matrix = np.zeros([len(snr), 8, 8])
    # ------------------------------------
    # load new data for test; File path of the data set
    # ------------------------------------
    for i in range(len(snr)):
        path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleighsnr\stest\Cons'
        dataFiletest = path + '\Con_' + str(2 * N_L_in) + '_Ds'+str(Ds)+'_' + str(num_tim) + '_' + str(
            N_Time) + '_3T_mod_CNN_1kind_sin_' + str(snr[i]) + '_dB120ruli_1.01sig.mat'
        # load test data and evaluate
        if net[jj] == 1:
            [input_two, output_two] = whether_slots_numpy_to_list(n_to_l=1, dataFile=dataFiletest, IQ=0, N_Time=N_Time)
            print('\nTesting ------------')
            loss, accuracy[0, i] = model.evaluate(input_two, output_two)
            matrix[i, :, :] = Modu_ways_statistics(input_two, model, output_two)
        else:
            [input_two, output_two] = whether_slots_numpy_to_list(n_to_l=1, dataFile=dataFiletest, IQ=0, N_Time=N_Time)
            print('\nTesting ------------')
            loss, accuracy[0, i] = model.evaluate(input_two, output_two)
            matrix[i, :, :] = Modu_ways_statistics(input_two, model, output_two)

        print('Identification matrix:\n', matrix[i, :, :])
        print('test loss: ', loss)
        print('the snr is ', snr[i])
        print('test accuracy: ', accuracy[0, i])
    print('test accuracy: ', accuracy)
    # scio.savemat(dataNew, {'acc1':accuracy, })
    dataNew = 'F:\matlab\plot_data\Compare\DS_'+str(Ds)+'\sDs'+str(Ds)+'con'+str(num_tim) +'net' + str(net[jj])+'_' + str(N_Time) + 'format' + str(
        2 * N_L_in) + '.mat'
    scio.savemat(dataNew, {'acc': accuracy, 'matrix': matrix})


