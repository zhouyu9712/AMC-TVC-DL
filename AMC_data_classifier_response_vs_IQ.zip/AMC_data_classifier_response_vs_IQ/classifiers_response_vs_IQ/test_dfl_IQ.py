from keras.models import Model,load_model
from sklearn.model_selection import train_test_split
from keras.callbacks import ModelCheckpoint

from CNN_mult_nets_ import *
from hard_judge import *
from readdata import *
N_L_in = 64
net=[3]
Ds=150
SNRK=24
tra_totaln = 76.8
for jj in range(0,len(net),1):
    N_OFDM_SYMS = 36000
    if net[jj] == 1 or net[jj] == 2:
        num_tim = 1024  # 3000,4000,5000,12000
    else:
        num_tim = N_OFDM_SYMS
    N_Time = math.floor(N_OFDM_SYMS / num_tim)

    path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleighsnr\stest_paper\IQ_two'
    # -----------------------------------------
    # use saved model
    # -----------------------------------------

    if net[jj] == 1:
        save_path = "E:\gradetwo_work\sNN_cla_python\save_net\AWGN\stra_MCBLDN_36\stmp_Ds0_crnn_R" + str(
            2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(int(num_tim / 100)) + ".h5"
    else:
        if net[jj] == 2:
            save_path = "E:\gradetwo_work\sNN_cla_python\save_net\AWGN\stra_MCCDN_36\stmp_Ds0_mcnn_R" + str(
                2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(int(num_tim / 100)) + ".h5"
        else:
            if net[jj] == 3:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\RESPONSE\Eightmod_vs_IQ\IQ_RN\DS_"+str(Ds)+"\stmp_Ds"+str(
                    Ds)+"snr0_"+str(SNRK-1)+"_scnn_L1_N" + str(int(num_tim / 100)) + "_"+str(tra_totaln)+"_0.74297.h5"
            else:
                save_path = "E:\gradetwo_work\sNN_cla_python\save_net\AWGN\stra_AlexNet_36\stmp_Ds0_scnn_L" + str(
                    N_Time) + "_N" + str(int(num_tim / 100)) + ".h5"
    checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)

    # -----------------------------------------
    # creat model
    # -----------------------------------------

    model = load_model(save_path)
    model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    model.summary()
    # snr = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43]
    # snr = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 20, 25, 30, 35, 40]#
    # snr = [1,3,5,7,9,11,13,15,17,19,21,23,25,27,29]#
    snr=np.linspace(0, SNRK-1,SNRK,endpoint=True, dtype='int8')
    accuracy = np.zeros([1, len(snr)])
    matrix = np.zeros([len(snr), 8, 8])
    # ------------------------------------
    # new data for test
    # ------------------------------------

    for i in range(len(snr)):
        if net[jj] == 1 or net[jj] == 2:
            dataFiletest = path + '\IQ_' + str(2 * N_L_in) + '_Ds'+ str(Ds) +'_' + str(num_tim) + '_' + str(N_Time) + '_3T_mod_CNN_1kind_sin_' + str(snr[i]) + '_dB120ruli_1.01sig.mat'
        else:
            dataFiletest = path + '\IQ_' + str(2 * N_L_in) + '_Ds'+ str(Ds) +'_' + str(num_tim) + '_' + str(N_Time) + '_3T_mod_CNN_1kind_sin_' + str(snr[i]) + '_dB120ruli_1.01sig.mat'

        [input_two, output_two] = mat_h5py_load(dataFiletest, IQ=1)
        if net[jj] == 1 or net[jj] == 2:
            names = locals()
            for x in range(0, N_Time):
                names['In_put_tra_%s' % x] = np.zeros([input_two.shape[0], 1, input_two.shape[2], input_two.shape[3]],
                                                      dtype='float16')
                names['In_put_tra_%s' % x][:, 0, :, :] = input_two[:, x, :, :]
            list1 = [names['In_put_tra_%s' % x] for x in range(N_Time)]

            print('\nTesting ------------')
            # Evaluate the model with the metrics we defined earlier
            loss, accuracy[0, i] = model.evaluate(list1, output_two)
            matrix[i, :, :] = Modu_ways_statistics(list1, model, output_two)
        else:
            print('\nTesting ------------')
            # Evaluate the model with the metrics we defined earlier
            loss, accuracy[0, i] = model.evaluate(input_two, output_two)
            matrix[i, :, :] = Modu_ways_statistics(input_two, model, output_two)

        print('Identification matrix:\n', matrix[i, :, :])
        print('test loss: ', loss)
        print('the snr is ', snr[i])
        print('test accuracy: ', accuracy[0, i])
    print('test accuracy: ', accuracy)

    dataNew = 'F:\周宇\研究生项目\调制方式识别\开始写论文\matlab\plot_data\Paper\DS_'+str(Ds)+'\sDs'+str(Ds)+'IQ'+str(N_OFDM_SYMS) +'net' + str(net[jj])+'_' + str(N_Time) + 'format' + str(
        2 * N_L_in) + '.mat'
    scio.savemat(dataNew, {'acc': accuracy, 'matrix': matrix})
    # scio.savemat(dataNew, {'acc1':accuracy, })

