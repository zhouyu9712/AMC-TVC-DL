from keras.models import Model,load_model
from sklearn.model_selection import train_test_split
from keras.callbacks import ModelCheckpoint
import math
from DNN_nets import *
from CNN_mult_nets_ import *
from hard_judge import *
from readdata import *

N_OFDM_SYMS   = 36000

DS_VEC = [10]
To=76.8
for dd in range(0,len(DS_VEC),1):

    if DS_VEC[dd]==10:
        R = [16]
    else:
        R = [64]

    for rr in range(0,len(R),1):
        N_L_in = R[rr]
        SNRK = 24
        path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleighsnr\stest_paper\Cons'
        # -----------------------------------------
        # use saved model
        # -----------------------------------------
        net = [3]
        for jj in range(0, len(net), 1):
            if net[jj] == 1 or net[jj] == 2:  #
                if DS_VEC[dd]==10:
                    num_tim = 4000  # 3000,4000,5000,12000
                else:
                    num_tim = 1200  # 3000,4000,5000,12000
            else:
                num_tim = N_OFDM_SYMS
            N_Time = math.floor(N_OFDM_SYMS / num_tim)
            if net[jj] == 1:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_SNR\MCCBLDN\DS_" + str(
                    DS_VEC[dd]) + "\stmp_Ds" + str(DS_VEC[dd]) + "_crnn_R" + str(2 * N_L_in) + "_L" + str(
                    N_Time) + "_N"+ str(int(num_tim)) + "To" + str(To) + "_0.92135.h5"

            else:
                if net[jj] == 2:
                    save_path = "E:\gradetwo_work\sNN_cla_python\save_net\AWGN\stra_MCCDN_36\stmp_Ds0_mcnn_R" + str(
                        2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(int(num_tim)) + ".h5"
                else:
                    save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\PAPER\DS_VS_SNR\SCDN\DS_" + str(
                        DS_VEC[dd]) + "\stmp_Ds" + str(DS_VEC[dd]) + "_scnn_R" + str(2 * N_L_in) + "_L" + str(
                        N_Time) + "_N" + str(int(num_tim)) + "To" + str(To) + ".h5"

            checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)

            # -----------------------------------------
            # creat model
            # -----------------------------------------

            model = load_model(save_path)
            model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()
            # snr = [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34, 37, 40, 43]
            # snr = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 20, 25, 30, 35, 40]#
            # snr = [1,3,5,7,9,11,13,15,17,19,21,23,25,27,29]#
            snr = np.linspace(0, SNRK-1 , SNRK, endpoint=True, dtype='int8')
            accuracy = np.zeros([1, len(snr)])
            matrix = np.zeros([len(snr), 8, 8])
            # ------------------------------------
            # new data for test
            # ------------------------------------

            for i in range(len(snr)):

                dataFiletest = path + '\Con_' + str(2 * N_L_in) + '_Ds' + str(DS_VEC[dd]) + '_' + str(
                    num_tim) + '_' + str(N_Time) + '_3T_mod_CNN_1kind_sin_' + str(snr[i]) + '_dB120ruli_1.01sig_uint8.mat'

                if net[jj] == 1 or net[jj] == 2:
                    [list1, output_train] = whether_slots_numpy_to_list(n_to_l=1, dataFile=dataFiletest, IQ=0,
                                                                        N_Time=N_Time)
                    print('\nTesting ------------')
                    # Evaluate the model with the metrics we defined earlier
                    loss, accuracy[0, i] = model.evaluate(list1, output_train)
                    matrix[i, :, :] = Modu_ways_statistics(list1, model, output_train)
                else:
                    [input_train, output_train] = whether_slots_numpy_to_list(n_to_l=0, dataFile=dataFiletest, IQ=0,
                                                                              N_Time=N_Time)
                    print('\nTesting ------------')
                    loss, accuracy[0, i] = model.evaluate(input_train, output_train)
                    matrix[i, :, :] = Modu_ways_statistics(input_train, model, output_train)

                print('Identification matrix:\n', matrix[i, :, :])
                print('test loss: ', loss)
                print('the snr is ', snr[i])
                print('test accuracy: ', accuracy[0, i])
            print('test accuracy: ', accuracy)

            dataNew = 'F:\周宇\研究生项目\调制方式识别\开始写论文\matlab\plot_data\Paper\DS_' + str(DS_VEC[dd]) + '\s' + str(2 * N_L_in) + 'net' + str(
                net[jj]) + 'format_Ds' + str(DS_VEC[dd]) + 'snr0-23.mat'
            scio.savemat(dataNew, {'acc': accuracy, 'matrix': matrix})
            # scio.savemat(dataNew, {'acc1':accuracy, })







