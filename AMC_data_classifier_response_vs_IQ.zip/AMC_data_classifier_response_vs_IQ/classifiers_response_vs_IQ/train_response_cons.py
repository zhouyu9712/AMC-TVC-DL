# -----------------------------------------
# import the necessary modules/fumction
# -----------------------------------------
from keras.models import Model, load_model
from keras.callbacks import ModelCheckpoint
from CNN_mult_nets_ import *
from readdata import *
# -----------------------------------------
# parameter setting
# -----------------------------------------
N_L_in       =  22                     # R resolution 16 ;for 2*32*32; 22 for 44*44
DS_VEC       =  [0,10]                 # Doppler shift parameter vector; 0 only for AWGN
N_SYMS1      =  1024                   # Data length of one frame
SNRK         =  15                     #  Number of SNR types 0:14
tra_totaln   =  240                    # the number of frame
net          =  [1]                  # net=1:MCBLDN; net=2:SCDN; response only use MCBLDN
# -----------------------------------------
# training process for 3 cycle
# 1. different classifiers
# 2. different doppler shift
# 3. different segmentation strategy
# -----------------------------------------
for jj in range(0,len(net),1):            #  cycle for classifiers
    IQ = 0
    if net[jj] == 1:
        num_tim = [1024,512]              # 512:R=16;1024:R=22
    else:
        num_tim = [N_SYMS1]               # the data length of each slots vector for slow fading channels
    for z in range(0, len(DS_VEC), 1):    # cycle for doppler shift
        Ds = DS_VEC[z]
        epch = 100
        for i in range(0, len(num_tim), 1):   #  cycle for segmentation strategy
            N_Time = math.floor(N_SYMS1 / num_tim[i])
            First_train = True
            train = 1
            # -----------------------------------------------------------------
            # when you are using train=0, test=1,please make frist_train=false
            # -----------------------------------------------------------------
            if train == 0 :
                First_train = False
            # -----------------------------------------
            # path of saved model
            # -----------------------------------------
            if net[jj] == 1:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\RESPONSE\Eightmod_vs_IQ\MCCBLDN\DS_" + str(
                    Ds ) + "\stmp_Ds" + str(
                    Ds ) + "_crnn_R" + str(2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(int(num_tim[i]))+"To" +str(tra_totaln)+ ".h5"
            else:
                save_path = "E:\gradetwo_work\sNN_cla_python\Save_classifier\RESPONSE\Eightmod_vs_IQ\SCDN\DS_" + str(
                    Ds ) + "\stmp_Ds" + str(Ds) + "_scnn_R" + str(2 * N_L_in) + "_L" + str(N_Time) + "_N" + str(
                    int(num_tim[i])) + "To" + str(tra_totaln) + ".h5"
            checkpoint = ModelCheckpoint(save_path, monitor='val_acc', verbose=1, save_best_only=True, period=1)

            # -----------------------------------------
            # creat model/ load saved model
            # -----------------------------------------
            if First_train == True:
                if net[jj] == 1:
                    model = CONRNN_sig_main(N_Time, 2 * N_L_in, 2 * N_L_in, 8,fiter=12)
                else:
                    model = CNN_single_main_3(2 * N_L_in, 2 * N_L_in, 8)
            else:
                model = load_model(save_path)
            model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
            model.summary()



            if train == 1:
                # -------------------------------------------------------------------------------
                # File path of the data set
                # -------------------------------------------------------------------------------
                path = 'E:\gradetwo_work\supload_classifier\matlab_produce_data\data\Rayleighsnr\strain\Cons'
                dataFile = path + '\Con_' + str(2 * N_L_in) + '_Ds' + str(Ds) + '_' + str(num_tim[i]) + '_' + str(
                    N_Time) + '_' + str(tra_totaln) + 'T_mod_CNN_'+str(SNRK)+'kind_MUL_dB120_ruili_1.01sig_0.mat'

                # ------------------------------------------
                # load train data
                # ------------------------------------------
                if net[jj] == 1:
                    [list1, output_train]=whether_slots_numpy_to_list(n_to_l=1,dataFile=dataFile,IQ=0,N_Time=N_Time)
                    print('Training ------------')
                    model.fit(list1, output_train, epochs=epch, batch_size=80, validation_split=0.15, verbose=2,
                              shuffle=True, callbacks=[checkpoint])
                else:
                    [input_train, output_train] = whether_slots_numpy_to_list(n_to_l=0, dataFile=dataFile, IQ=0, N_Time=N_Time)
                    print('Training ------------')
                    model.fit(input_train, output_train, epochs=epch, batch_size=300,  validation_split=0.15, verbose=2,
                              shuffle=True, callbacks=[checkpoint])

            else:
                print('there is not train ')












